export default [
  {
    id: 'AGE5',
    value: '유아 5세'
  },
  {
    id: 'AGE6',
    value: '유아 6세'
  },
  {
    id: 'AGE7',
    value: '유아 7세'
  },
  {
    id: 'AGE8',
    value: '초등학교 1학년'
  },
  {
    id: 'AGE9',
    value: '초등학교 2학년'
  },
  {
    id: 'AGE10',
    value: '초등학교 3학년'
  },
  {
    id: 'AGE11',
    value: '초등학교 4학년'
  },
  {
    id: 'AGE12',
    value: '초등학교 5학년'
  },
  {
    id: 'AGE13',
    value: '초등학교 6학년'
  },
  {
    id: 'AGE14',
    value: '중학교 1학년'
  },
  {
    id: 'AGE15',
    value: '중학교 2학년'
  },
  {
    id: 'AGE16',
    value: '중학교 3학년'
  },
  {
    id: 'AGE17',
    value: '고등학교 1학년'
  },
  {
    id: 'AGE18',
    value: '고등학교 2학년'
  },
  {
    id: 'AGE19',
    value: '고등학교 3학년'
  }
]