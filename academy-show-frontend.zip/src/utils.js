/**
 * This file contains utilities functions
 */

import axios from "axios";
import store, {STORE_COMMENDS} from "@/store"

import CONFIG from "./config";

/**
 * External API Requesters
 */
const BaseApiRequester = (() => {
  const AxiosInstance = axios.create({
    timeout: CONFIG.API_TIMEOUT,
  });

  return {
    'get': (url, config) => AxiosInstance.get(url, config),
    'post': (url, data, config) => AxiosInstance.post(url, data, config),
    'delete': (url, config) => AxiosInstance.delete(url, config),
    'patch': (url, data, config) => AxiosInstance.patch(url, data, config),
  }
})();
 
const ApiRequester = (() => {
  const makeConfig = () => {
    const config = {};

    if(AuthUtil.hasAccessToken()) {
      config.headers = {
        Authorization: `${CONFIG.MAIN_API_TOKEN_PREFIX} ${store.state.accessToken}` 
      };
    }

    return config;
  }

  return {
    'get': (url) => BaseApiRequester.get(url, makeConfig()),
    'post': (url, data) => BaseApiRequester.post(url, data, makeConfig()),
    'delete': (url) => BaseApiRequester.delete(url, makeConfig()),
    'patch': (url, data) => BaseApiRequester.patch(url, data, makeConfig()),
  }
})();

/**
 * jwt token handling utils
 */
 const AuthUtil = {
  setAccessToken: (response) => {
    store.commit(STORE_COMMENDS.MUTATIONS.ACCESS_TOKEN, response.headers.authorization);
  },
  getAccessToken: () => {
    return store.state.accessToken;
  },
  hasAccessToken: () => {
    const token = AuthUtil.getAccessToken();
    return !(!token || /^\s*$/.test(token));
  }
}


export { BaseApiRequester, ApiRequester, AuthUtil };
