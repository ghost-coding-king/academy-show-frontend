<template>
  <v-row style="margin-top: 50px" no-gutters>
    <v-col cols="1"></v-col>
    <h1>내 리뷰보기</h1>
  </v-row>
</template>

<script>
export default {

}
</script>

<style>

</style>