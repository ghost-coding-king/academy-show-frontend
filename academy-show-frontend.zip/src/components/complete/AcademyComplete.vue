<template>
  <v-row style="background-color: #f7f7f7; text-align: left; margin-top: 20px; padding: 13px;">
  
    • 학원 회원으로 가입하셨습니다. 학원 관리와 수정을 하실 수 있습니다.<br>
    • 일반 회원과 동일한 서비스도 이용 가능합니다.
  
  </v-row>
</template>

<script>
export default {

}
</script>

<style>

</style>